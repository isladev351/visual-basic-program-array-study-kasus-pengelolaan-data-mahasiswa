﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txbNama = New System.Windows.Forms.TextBox()
        Me.txbNPM = New System.Windows.Forms.TextBox()
        Me.txbAlamat = New System.Windows.Forms.TextBox()
        Me.txbWilayah = New System.Windows.Forms.TextBox()
        Me.txbNotelpon = New System.Windows.Forms.TextBox()
        Me.txbEmail = New System.Windows.Forms.TextBox()
        Me.btnTampilkan = New System.Windows.Forms.Button()
        Me.btnUbah = New System.Windows.Forms.Button()
        Me.btnKeluar = New System.Windows.Forms.Button()
        Me.cmbKota = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnBersih = New System.Windows.Forms.Button()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnTambah = New System.Windows.Forms.Button()
        Me.txbCari = New System.Windows.Forms.TextBox()
        Me.btnCari = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "NPM"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(354, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Alamat"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(354, 61)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Kota"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(354, 109)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Wilayah"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 109)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "No Telp"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(36, 159)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Email"
        '
        'txbNama
        '
        Me.txbNama.Location = New System.Drawing.Point(139, 22)
        Me.txbNama.Name = "txbNama"
        Me.txbNama.Size = New System.Drawing.Size(175, 20)
        Me.txbNama.TabIndex = 7
        Me.txbNama.Text = "   "
        '
        'txbNPM
        '
        Me.txbNPM.Enabled = False
        Me.txbNPM.Location = New System.Drawing.Point(139, 62)
        Me.txbNPM.Name = "txbNPM"
        Me.txbNPM.Size = New System.Drawing.Size(175, 20)
        Me.txbNPM.TabIndex = 8
        '
        'txbAlamat
        '
        Me.txbAlamat.Location = New System.Drawing.Point(466, 19)
        Me.txbAlamat.Name = "txbAlamat"
        Me.txbAlamat.Size = New System.Drawing.Size(175, 20)
        Me.txbAlamat.TabIndex = 9
        '
        'txbWilayah
        '
        Me.txbWilayah.Location = New System.Drawing.Point(466, 102)
        Me.txbWilayah.Name = "txbWilayah"
        Me.txbWilayah.Size = New System.Drawing.Size(175, 20)
        Me.txbWilayah.TabIndex = 11
        '
        'txbNotelpon
        '
        Me.txbNotelpon.Location = New System.Drawing.Point(139, 106)
        Me.txbNotelpon.Name = "txbNotelpon"
        Me.txbNotelpon.Size = New System.Drawing.Size(175, 20)
        Me.txbNotelpon.TabIndex = 12
        '
        'txbEmail
        '
        Me.txbEmail.Location = New System.Drawing.Point(139, 156)
        Me.txbEmail.Name = "txbEmail"
        Me.txbEmail.Size = New System.Drawing.Size(175, 20)
        Me.txbEmail.TabIndex = 13
        '
        'btnTampilkan
        '
        Me.btnTampilkan.Location = New System.Drawing.Point(36, 207)
        Me.btnTampilkan.Name = "btnTampilkan"
        Me.btnTampilkan.Size = New System.Drawing.Size(75, 23)
        Me.btnTampilkan.TabIndex = 14
        Me.btnTampilkan.Text = "Tampilkan"
        Me.btnTampilkan.UseVisualStyleBackColor = True
        '
        'btnUbah
        '
        Me.btnUbah.Enabled = False
        Me.btnUbah.Location = New System.Drawing.Point(188, 471)
        Me.btnUbah.Name = "btnUbah"
        Me.btnUbah.Size = New System.Drawing.Size(75, 23)
        Me.btnUbah.TabIndex = 15
        Me.btnUbah.Text = "Edit"
        Me.btnUbah.UseVisualStyleBackColor = True
        '
        'btnKeluar
        '
        Me.btnKeluar.Location = New System.Drawing.Point(655, 471)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(75, 23)
        Me.btnKeluar.TabIndex = 16
        Me.btnKeluar.Text = "Keluar"
        Me.btnKeluar.UseVisualStyleBackColor = True
        '
        'cmbKota
        '
        Me.cmbKota.FormattingEnabled = True
        Me.cmbKota.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.cmbKota.Location = New System.Drawing.Point(466, 61)
        Me.cmbKota.Name = "cmbKota"
        Me.cmbKota.Size = New System.Drawing.Size(121, 21)
        Me.cmbKota.TabIndex = 17
        Me.cmbKota.Text = " "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnCari)
        Me.GroupBox1.Controls.Add(Me.txbCari)
        Me.GroupBox1.Controls.Add(Me.btnTambah)
        Me.GroupBox1.Controls.Add(Me.btnBersih)
        Me.GroupBox1.Controls.Add(Me.cmbKota)
        Me.GroupBox1.Controls.Add(Me.btnTampilkan)
        Me.GroupBox1.Controls.Add(Me.txbEmail)
        Me.GroupBox1.Controls.Add(Me.txbNotelpon)
        Me.GroupBox1.Controls.Add(Me.txbWilayah)
        Me.GroupBox1.Controls.Add(Me.txbAlamat)
        Me.GroupBox1.Controls.Add(Me.txbNPM)
        Me.GroupBox1.Controls.Add(Me.txbNama)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(30, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(732, 241)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Form Mahasiswa"
        '
        'btnBersih
        '
        Me.btnBersih.Location = New System.Drawing.Point(582, 207)
        Me.btnBersih.Name = "btnBersih"
        Me.btnBersih.Size = New System.Drawing.Size(118, 23)
        Me.btnBersih.TabIndex = 19
        Me.btnBersih.Text = "bersihkan form"
        Me.btnBersih.UseVisualStyleBackColor = True
        '
        'btnHapus
        '
        Me.btnHapus.Enabled = False
        Me.btnHapus.Location = New System.Drawing.Point(30, 471)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(75, 23)
        Me.btnHapus.TabIndex = 18
        Me.btnHapus.Text = "hapus"
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.AllowColumnReorder = True
        Me.ListView1.HideSelection = False
        Me.ListView1.HoverSelection = True
        Me.ListView1.LabelEdit = True
        Me.ListView1.Location = New System.Drawing.Point(30, 274)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(732, 180)
        Me.ListView1.TabIndex = 19
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'btnSimpan
        '
        Me.btnSimpan.Enabled = False
        Me.btnSimpan.Location = New System.Drawing.Point(269, 471)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(75, 23)
        Me.btnSimpan.TabIndex = 19
        Me.btnSimpan.Text = "Simpan"
        Me.btnSimpan.UseVisualStyleBackColor = True
        '
        'btnBatal
        '
        Me.btnBatal.Enabled = False
        Me.btnBatal.Location = New System.Drawing.Point(348, 471)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(75, 23)
        Me.btnBatal.TabIndex = 20
        Me.btnBatal.Text = "batal"
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'btnTambah
        '
        Me.btnTambah.Location = New System.Drawing.Point(118, 206)
        Me.btnTambah.Name = "btnTambah"
        Me.btnTambah.Size = New System.Drawing.Size(75, 23)
        Me.btnTambah.TabIndex = 20
        Me.btnTambah.Text = "Tambah"
        Me.btnTambah.UseVisualStyleBackColor = True
        '
        'txbCari
        '
        Me.txbCari.Location = New System.Drawing.Point(347, 210)
        Me.txbCari.Name = "txbCari"
        Me.txbCari.Size = New System.Drawing.Size(100, 20)
        Me.txbCari.TabIndex = 21
        '
        'btnCari
        '
        Me.btnCari.Location = New System.Drawing.Point(453, 208)
        Me.btnCari.Name = "btnCari"
        Me.btnCari.Size = New System.Drawing.Size(75, 23)
        Me.btnCari.TabIndex = 22
        Me.btnCari.Text = "Cari"
        Me.btnCari.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(787, 586)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.btnKeluar)
        Me.Controls.Add(Me.btnSimpan)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnUbah)
        Me.Name = "Form1"
        Me.Text = "Pengelolaan Data Mahasiswa"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txbNama As TextBox
    Friend WithEvents txbNPM As TextBox
    Friend WithEvents txbAlamat As TextBox
    Friend WithEvents txbWilayah As TextBox
    Friend WithEvents txbNotelpon As TextBox
    Friend WithEvents txbEmail As TextBox
    Friend WithEvents btnTampilkan As Button
    Friend WithEvents btnUbah As Button
    Friend WithEvents btnKeluar As Button
    Friend WithEvents cmbKota As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ListView1 As ListView
    Friend WithEvents btnHapus As Button
    Friend WithEvents btnSimpan As Button
    Friend WithEvents btnBatal As Button
    Friend WithEvents btnBersih As Button
    Friend WithEvents btnTambah As Button
    Friend WithEvents btnCari As Button
    Friend WithEvents txbCari As TextBox
End Class
