﻿Public Class Form1
    Dim listdata As ListViewItem
    Dim data(6) As String
    Dim npm As Long
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListView1.GridLines = True
        ListView1.View = View.Details
        ListView1.Columns.Add("Nama")
        ListView1.Columns.Add("NPM")
        ListView1.Columns.Add("No Telp ")
        ListView1.Columns.Add("Email")
        ListView1.Columns.Add("Alamat")
        ListView1.Columns.Add("Kota")
        ListView1.Columns.Add("Wilayah")
        ListView1.LabelEdit = True
        npm = 197064516200
        txbNPM.Text = "Di Buat Oleh Sistem"


    End Sub

    Private Sub kosong()
        txbNama.Text = ""
        txbEmail.Text = ""
        txbNotelpon.Text = ""
        txbAlamat.Text = ""
        cmbKota.Text = ""
        txbWilayah.Text = ""
        txbNama.Focus()
    End Sub



    Private Sub cmbKota_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbKota.SelectedIndexChanged
        If cmbKota.Text = "1" Then
            txbWilayah.Text = "Jakarta Pusat"
        ElseIf cmbKota.Text = "2" Then
            txbWilayah.Text = "Jakarta Barat"
        ElseIf cmbKota.Text = "3" Then
            txbWilayah.Text = "Jakarta Selatan"
        ElseIf cmbKota.Text = "4" Then
            txbWilayah.Text = "Jakarta Timur"
        ElseIf cmbKota.Text = "2" Then
            txbWilayah.Text = "Jakarta Utara"
        End If
    End Sub

    Private Sub tampilkan()

        data(0) = txbNama.Text
        data(1) = txbNPM.Text
        data(2) = txbNotelpon.Text
        data(3) = txbEmail.Text
        data(4) = txbAlamat.Text
        data(5) = cmbKota.Text
        data(6) = txbWilayah.Text

        listdata = New ListViewItem
        listdata = ListView1.Items.Add(data(0), 3000)
        listdata.SubItems.Add(data(1) - 1)
        listdata.SubItems.Add(data(2))
        listdata.SubItems.Add(data(3))
        listdata.SubItems.Add(data(4))
        listdata.SubItems.Add(data(5))
        listdata.SubItems.Add(data(6))
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnTampilkan.Click
        GroupBox1.Text = "Form Mahasiswa"
        If txbNama.Text = "" Then
            MsgBox("Nama Belum Diisi!")
        ElseIf txbNPM.Text = "" Then
            MsgBox("NPM belum diisi")
        ElseIf txbEmail.Text = "" Then
            MsgBox(" Email belum diisi")
        ElseIf txbAlamat.Text = "" Then
            MsgBox("Alamat belum diisi")
        ElseIf txbNotelpon.Text = "" Then
            MsgBox(" No Telpon belum diisi")
        ElseIf cmbKota.Text = "" Then
            MsgBox(" Kota belum diisi")
        Else
            npm += 1
            txbNPM.Text = npm.ToString
            tampilkan()
            txbNPM.Text = ""
            kosong()
            txbenablefalse()
            btnTampilkan.Enabled = False
        End If
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        btnUbah.Enabled = True
        btnHapus.Enabled = True


    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        Dim yesNo As String
        yesNo = MsgBox("Anda Yakin Menghapus Data Ini", MsgBoxStyle.YesNo, "Pesan")
        If yesNo = DialogResult.Yes Then
            btnTambah.Enabled = True
            btnUbah.Enabled = False
            btnSimpan.Enabled = False
            btnBatal.Enabled = False

            For Each i As ListViewItem In ListView1.SelectedItems
                ListView1.Items.Remove(i)
            Next
            kosong()
            MsgBox("Data Berhasil Dihapus!")

        End If
    End Sub

    Private Sub btnUbah_Click(sender As Object, e As EventArgs) Handles btnUbah.Click
        txbenabletrue()
        btnTambah.Enabled = False
        btnSimpan.Enabled = True
        btnBatal.Enabled = True
        btnTampilkan.Enabled = False
        GroupBox1.Text = "Edit Form Mahasiswa"

        Try
            Dim s As ListViewItem
            s = ListView1.SelectedItems(0)
            txbNama.Text = s.Text
            txbNPM.Text = s.SubItems(1).Text
            txbNotelpon.Text = s.SubItems(2).Text
            txbEmail.Text = s.SubItems(3).Text
            txbAlamat.Text = s.SubItems(4).Text
            cmbKota.Text = s.SubItems(5).Text
            txbWilayah.Text = s.SubItems(6).Text
        Catch ex As Exception
            MsgBox("pilih data !")
        End Try

    End Sub


    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btnBatal.Click
        btnTambah.Enabled = True
        btnUbah.Enabled = False
        btnSimpan.Enabled = False
        btnBatal.Enabled = False
        btnTampilkan.Enabled = False
        GroupBox1.Text = "Form Mahasiswa"
        kosong()
        txbNPM.Text = ""
        txbenablefalse()
    End Sub

    Private Sub txbenablefalse()
        txbNama.Enabled = False
        txbNPM.Enabled = False
        txbEmail.Enabled = False
        txbNotelpon.Enabled = False
        txbAlamat.Enabled = False
        cmbKota.Enabled = False
        txbWilayah.Enabled = False
    End Sub

    Private Sub txbenabletrue()
        txbNama.Enabled = True
        txbEmail.Enabled = True
        txbNPM.Enabled = False
        txbNotelpon.Enabled = True
        txbAlamat.Enabled = True
        cmbKota.Enabled = True
        txbWilayah.Enabled = True
    End Sub

    Private Sub Button1_Click_2(sender As Object, e As EventArgs) Handles btnBersih.Click
        txbNPM.Enabled = False
        kosong()
    End Sub

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        txbenablefalse()
        btnTambah.Enabled = True
        GroupBox1.Text = "Form Mahasiswa"
        'temukan file data yang ingin diiubah

        Dim c As ListViewItem
        c = ListView1.SelectedItems(0)
        c.Text = txbNama.Text
        c.SubItems(1).Text = txbNPM.Text
        c.SubItems(2).Text = txbNotelpon.Text
        c.SubItems(3).Text = txbEmail.Text
        c.SubItems(4).Text = txbAlamat.Text
        c.SubItems(5).Text = cmbKota.Text
        c.SubItems(6).Text = txbWilayah.Text
        txbNPM.Text = ""
        kosong()
        btnSimpan.Enabled = False
        btnBatal.Enabled = False
        txbNama.Text = ""
        MsgBox("Data Berhasil Di Edit")
    End Sub

    Private Sub btnKeluar_Click(sender As Object, e As EventArgs) Handles btnKeluar.Click
        End
    End Sub

    Private Sub btnTambah_Click(sender As Object, e As EventArgs) Handles btnTambah.Click
        GroupBox1.Text = "Tambah Data Mahasiswa"
        txbenabletrue()
        kosong()
        txbNama.Focus()
        btnTampilkan.Enabled = True
        txbNPM.Text = npm.ToString

        btnHapus.Enabled = False
        btnUbah.Enabled = False
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click
        Dim x As Integer
        Dim searchstring As String = txbCari.Text
        ListView1.SelectedIndices.Clear()
        For Each lvi As ListViewItem In ListView1.Items
            For Each lvisub As ListViewItem.ListViewSubItem In lvi.SubItems
                If lvisub.Text = searchstring Then
                    ListView1.SelectedIndices.Add(lvi.Index)
                    x = 1
                    Exit For
                End If
            Next
        Next
        If x = 1 Then
            ListView1.Focus()
            MsgBox("Data Berhasil Ditemukan")
        Else
            MsgBox("Data Tidak Ditemukan")
        End If

    End Sub
End Class
